import { useEffect, useState } from "react";
import { HashRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider, useTheme } from "@/theme/ThemeProvider";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { TopNavigation } from "@/components/TopNavigation";
import type { DashboardLayout } from "@/theme/presets";

const SIDEBAR_LAYOUTS: DashboardLayout[] = ["default", "split", "icon-menu", "paper", "adaptive"];

function WorkspacePlaceholder() {
  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-semibold tracking-tight">CBMS Workspace</h1>
      <p className="text-sm text-muted-foreground">
        Portal sections will be wired to the Laravel backend under <code>api/v1</code>.
      </p>
    </div>
  );
}

function Shell() {
  const { theme, update } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [topNavOpen, setTopNavOpen] = useState(false);
  const layout = theme.layout;

  useEffect(() => {
    setSidebarOpen(false);
    setTopNavOpen(false);
  }, [layout]);
  const hasSidebar = SIDEBAR_LAYOUTS.includes(layout);
  const isSplit = layout === "split";
  const isIconMenu = layout === "icon-menu";
  const sidebarCollapsed = isIconMenu || (layout !== "adaptive" && !isSplit && theme.sidebarMode === "icon");
  const canCollapseSidebar = layout === "default" || layout === "paper";
  const sidebarWidth = isSplit
    ? "md:pl-[17rem]"
    : layout === "adaptive"
      ? "md:pl-[17rem]"
    : isIconMenu || (sidebarCollapsed && hasSidebar)
      ? "md:pl-[4.5rem]"
      : theme.sidebarMode === "full" && hasSidebar
        ? "md:pl-72"
        : hasSidebar
          ? "md:pl-64"
          : "md:pl-0";
  const boxed = theme.contentWidth === "compact";
  const closeTopNavigation = () => setTopNavOpen(false);

  const sidebar = hasSidebar ? (
    <Sidebar
      open={sidebarOpen}
      collapsed={sidebarCollapsed}
      mode={theme.sidebarMode}
      layout={layout}
      onClose={() => setSidebarOpen(false)}
    />
  ) : null;

  const header = (
    <Header
      layout={layout}
      hasSidebar={hasSidebar}
      navigationOpen={hasSidebar ? sidebarOpen : topNavOpen}
      canCollapseSidebar={canCollapseSidebar}
      onMenuClick={() => hasSidebar ? setSidebarOpen(true) : setTopNavOpen((open) => !open)}
      onCollapseClick={() => update({ sidebarMode: sidebarCollapsed ? "default" : "icon" })}
    />
  );

  const pageContent = (
    <main className="min-w-0 flex-1 p-4 sm:p-6">
      <div className={boxed ? "mx-auto w-full max-w-5xl space-y-6" : "mx-auto w-full max-w-[1600px] space-y-6"}>
        <Routes>
          <Route path="*" element={<WorkspacePlaceholder />} />
        </Routes>
      </div>
    </main>
  );

  return (
    <div className={`app-shell app-shell-${layout} min-h-screen bg-background`} data-layout={layout}>
      {sidebar}
      {layout === "horizontal" && <TopNavigation variant="horizontal" mobileOpen={topNavOpen} onNavigate={closeTopNavigation} />}
      <div className={`app-shell-main flex min-h-screen min-w-0 flex-col transition-[padding] duration-200 ${sidebarWidth}`}>
        <div className={layout === "paper" ? "paper-canvas mx-auto my-2 flex min-h-[calc(100dvh-1rem)] w-[calc(100%-1rem)] max-w-[1900px] flex-1 flex-col overflow-hidden rounded-2xl border bg-background shadow-sm sm:my-4 sm:min-h-[calc(100dvh-2rem)] sm:w-[calc(100%-2rem)]" : "flex min-h-screen flex-1 flex-col"}>
          {header}
          {layout === "full-navbar" && <TopNavigation variant="full-navbar" mobileOpen={topNavOpen} onNavigate={closeTopNavigation} />}
          {pageContent}
        </div>
      </div>
    </div>
  );
}

export function App() {
  return (
    <ThemeProvider>
      <HashRouter>
        <Shell />
      </HashRouter>
    </ThemeProvider>
  );
}
