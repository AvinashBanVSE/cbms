export type ThemeMode = "light" | "dark" | "system";

export type SidebarVariant = "default" | "floating" | "inset";

export type ContentWidth = "full" | "compact";

export type SidebarMode = "default" | "icon" | "full";

/** Complete application shell layout, independent from color/theme settings. */
export type DashboardLayout = "default" | "full-navbar" | "horizontal" | "split" | "icon-menu" | "paper" | "adaptive";

export interface ThemeColors {
  primary: string;
  primaryForeground: string;
  secondary: string;
  secondaryForeground: string;
  accent: string;
  accentForeground: string;
  background: string;
  foreground: string;
  card: string;
  cardForeground: string;
  muted: string;
  mutedForeground: string;
  border: string;
  input: string;
  ring: string;
  destructive: string;
  destructiveForeground: string;
}

export interface ThemeFont {
  family: string;
  scale: number;
}

export interface ThemeState {
  mode: ThemeMode;
  colors: ThemeColors;
  darkColors: ThemeColors;
  font: ThemeFont;
  radius: number;
  sidebarVariant: SidebarVariant;
  sidebarMode: SidebarMode;
  layout: DashboardLayout;
  contentWidth: ContentWidth;
  preset: string;
}

export const FONT_OPTIONS = [
  { label: "System UI", value: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" },
  { label: "Inter", value: "'Inter', system-ui, sans-serif" },
  { label: "Roboto", value: "'Roboto', system-ui, sans-serif" },
  { label: "Poppins", value: "'Poppins', system-ui, sans-serif" },
  { label: "Nunito", value: "'Nunito', system-ui, sans-serif" },
  { label: "IBM Plex Sans", value: "'IBM Plex Sans', system-ui, sans-serif" },
  { label: "JetBrains Mono", value: "'JetBrains Mono', monospace" },
];

export interface PresetTheme {
  name: string;
  label: string;
  swatch: string;
  colors: ThemeColors;
  darkColors: ThemeColors;
}

const mk = (
  primary: string, primaryForeground: string, secondary: string, secondaryForeground: string,
  accent: string, accentForeground: string, background: string, foreground: string,
  card: string, cardForeground: string, muted: string, mutedForeground: string,
  border: string, input: string, ring: string, destructive: string, destructiveForeground: string,
): ThemeColors => ({
  primary, primaryForeground, secondary, secondaryForeground, accent, accentForeground,
  background, foreground, card, cardForeground, muted, mutedForeground, border, input, ring,
  destructive, destructiveForeground,
});

const darkSet = (p: string, ring: string, accent: string): ThemeColors =>
  mk(
    p, "0 0% 98%",
    "240 5% 12%", "0 0% 98%",
    accent, "0 0% 98%",
    "240 10% 4%", "0 0% 95%",
    "240 10% 6%", "0 0% 95%",
    "240 6% 10%", "240 5% 60%",
    "240 6% 14%", "240 6% 14%",
    ring, "0 72% 51%", "0 0% 98%",
  );

export const PRESET_THEMES: PresetTheme[] = [
  {
    name: "default",
    label: "Default",
    swatch: "hsl(224.3 76.3% 48%)",
    colors: mk("224.3 76.3% 48%", "0 0% 100%", "240 4.8% 95.9%", "240 5.9% 10%", "240 4.8% 95.9%", "240 5.9% 10%", "0 0% 100%", "240 5.9% 10%", "0 0% 100%", "240 5.9% 10%", "240 4.8% 95.9%", "240 3.8% 46.1%", "240 5.9% 90%", "240 5.9% 90%", "224.3 76.3% 48%", "0 84.2% 60.2%", "0 0% 100%"),
    darkColors: darkSet("224.3 76.3% 48%", "224.3 76.3% 48%", "240 5% 12%"),
  },
  {
    name: "blue",
    label: "Ocean Blue",
    swatch: "hsl(210 90% 48%)",
    colors: mk("210 90% 48%", "0 0% 100%", "210 30% 95%", "210 20% 12%", "210 40% 95%", "210 20% 12%", "0 0% 100%", "210 20% 12%", "0 0% 100%", "210 20% 12%", "210 30% 96%", "210 10% 42%", "210 20% 90%", "210 20% 90%", "210 90% 48%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("210 90% 55%", "210 90% 55%", "210 30% 14%"),
  },
  {
    name: "violet",
    label: "Violet",
    swatch: "hsl(262 83% 58%)",
    colors: mk("262 83% 58%", "0 0% 100%", "262 20% 96%", "262 15% 12%", "262 30% 96%", "262 15% 12%", "0 0% 100%", "262 15% 12%", "0 0% 100%", "262 15% 12%", "262 20% 96%", "262 8% 44%", "262 15% 90%", "262 15% 90%", "262 83% 58%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("262 83% 65%", "262 83% 65%", "262 20% 14%"),
  },
  {
    name: "emerald",
    label: "Emerald",
    swatch: "hsl(160 84% 39%)",
    colors: mk("160 84% 39%", "0 0% 100%", "160 20% 95%", "160 15% 12%", "160 30% 95%", "160 15% 12%", "0 0% 100%", "160 15% 12%", "0 0% 100%", "160 15% 12%", "160 20% 96%", "160 8% 40%", "160 15% 90%", "160 15% 90%", "160 84% 39%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("160 84% 48%", "160 84% 48%", "160 20% 14%"),
  },
  {
    name: "rose",
    label: "Rose",
    swatch: "hsl(346 77% 49%)",
    colors: mk("346 77% 49%", "0 0% 100%", "346 20% 96%", "346 15% 12%", "346 30% 96%", "346 15% 12%", "0 0% 100%", "346 15% 12%", "0 0% 100%", "346 15% 12%", "346 20% 96%", "346 8% 42%", "346 15% 90%", "346 15% 90%", "346 77% 49%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("346 77% 58%", "346 77% 58%", "346 20% 14%"),
  },
  {
    name: "orange",
    label: "Orange",
    swatch: "hsl(24 94% 50%)",
    colors: mk("24 94% 50%", "0 0% 100%", "24 25% 96%", "24 15% 12%", "24 35% 95%", "24 15% 12%", "0 0% 100%", "24 15% 12%", "0 0% 100%", "24 15% 12%", "24 25% 96%", "24 8% 42%", "24 15% 90%", "24 15% 90%", "24 94% 50%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("24 94% 58%", "24 94% 58%", "24 25% 14%"),
  },
  {
    name: "amber",
    label: "Amber",
    swatch: "hsl(45 96% 47%)",
    colors: mk("45 96% 40%", "0 0% 12%", "45 30% 95%", "45 15% 12%", "45 40% 94%", "45 15% 12%", "0 0% 100%", "45 15% 12%", "0 0% 100%", "45 15% 12%", "45 30% 96%", "45 8% 38%", "45 15% 88%", "45 15% 88%", "45 96% 40%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("45 96% 52%", "45 96% 52%", "45 30% 14%"),
  },
  {
    name: "teal",
    label: "Teal",
    swatch: "hsl(174 72% 40%)",
    colors: mk("174 72% 40%", "0 0% 100%", "174 25% 95%", "174 15% 12%", "174 35% 95%", "174 15% 12%", "0 0% 100%", "174 15% 12%", "0 0% 100%", "174 15% 12%", "174 25% 96%", "174 8% 40%", "174 15% 90%", "174 15% 90%", "174 72% 40%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("174 72% 48%", "174 72% 48%", "174 25% 14%"),
  },
  {
    name: "indigo",
    label: "Indigo",
    swatch: "hsl(239 84% 60%)",
    colors: mk("239 84% 60%", "0 0% 100%", "239 25% 96%", "239 15% 12%", "239 35% 96%", "239 15% 12%", "0 0% 100%", "239 15% 12%", "0 0% 100%", "239 15% 12%", "239 25% 96%", "239 8% 44%", "239 15% 90%", "239 15% 90%", "239 84% 60%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("239 84% 68%", "239 84% 68%", "239 25% 14%"),
  },
  {
    name: "mono",
    label: "Monochrome",
    swatch: "hsl(0 0% 20%)",
    colors: mk("0 0% 20%", "0 0% 100%", "0 0% 96%", "0 0% 12%", "0 0% 96%", "0 0% 12%", "0 0% 100%", "0 0% 12%", "0 0% 100%", "0 0% 12%", "0 0% 96%", "0 0% 42%", "0 0% 90%", "0 0% 90%", "0 0% 20%", "0 84% 60%", "0 0% 100%"),
    darkColors: darkSet("0 0% 90%", "0 0% 90%", "0 0% 14%"),
  },
];

export const DEFAULT_THEME: ThemeState = {
  mode: "system",
  colors: PRESET_THEMES[0].colors,
  darkColors: PRESET_THEMES[0].darkColors,
  font: { family: FONT_OPTIONS[0].value, scale: 1 },
  radius: 0.5,
  sidebarVariant: "default",
  sidebarMode: "default",
  layout: "default",
  contentWidth: "full",
  preset: "default",
};
