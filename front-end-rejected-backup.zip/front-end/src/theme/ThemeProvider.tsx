import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { DEFAULT_THEME, FONT_OPTIONS, PRESET_THEMES } from "./presets";
import type { ThemeColors, ThemeState } from "./presets";

const STORAGE_KEY = "cbms-theme-v1";

const HSL_TOKEN_PATTERN = /^\s*([\d.]+)\s+([\d.]+)%\s+([\d.]+)%\s*$/;

export function hslToHex(hsl: string): string {
  const m = hsl.match(HSL_TOKEN_PATTERN);
  if (!m) return "#000000";
  const h = Number(m[1]);
  const s = Number(m[2]) / 100;
  const l = Number(m[3]) / 100;
  if (![h, s, l].every(Number.isFinite) || h < 0 || h > 360 || s < 0 || s > 1 || l < 0 || l > 1) return "#000000";
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const hp = h / 60;
  const x = c * (1 - Math.abs((hp % 2) - 1));
  let r = 0, g = 0, b = 0;
  if (hp >= 0 && hp < 1) [r, g, b] = [c, x, 0];
  else if (hp < 2) [r, g, b] = [x, c, 0];
  else if (hp < 3) [r, g, b] = [0, c, x];
  else if (hp < 4) [r, g, b] = [0, x, c];
  else if (hp < 5) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  const mm = l - c / 2;
  const to = (v: number) => Math.round((v + mm) * 255).toString(16).padStart(2, "0");
  return `#${to(r)}${to(g)}${to(b)}`;
}

export function hslToHslString(hsl: string): string {
  const m = hsl.match(HSL_TOKEN_PATTERN);
  if (!m) return "hsl(0 0% 0%)";
  const values = m.slice(1).map(Number);
  if (!values.every(Number.isFinite) || values[0] < 0 || values[0] > 360 || values[1] < 0 || values[1] > 100 || values[2] < 0 || values[2] > 100) return "hsl(0 0% 0%)";
  return `hsl(${values[0]} ${values[1]}% ${values[2]}%)`;
}

function colorVars(c: ThemeColors): Record<string, string> {
  return {
    "--primary": `hsl(${c.primary})`,
    "--primary-foreground": `hsl(${c.primaryForeground})`,
    "--secondary": `hsl(${c.secondary})`,
    "--secondary-foreground": `hsl(${c.secondaryForeground})`,
    "--accent": `hsl(${c.accent})`,
    "--accent-foreground": `hsl(${c.accentForeground})`,
    "--background": `hsl(${c.background})`,
    "--foreground": `hsl(${c.foreground})`,
    "--card": `hsl(${c.card})`,
    "--card-foreground": `hsl(${c.cardForeground})`,
    "--popover": `hsl(${c.card})`,
    "--popover-foreground": `hsl(${c.cardForeground})`,
    "--muted": `hsl(${c.muted})`,
    "--muted-foreground": `hsl(${c.mutedForeground})`,
    "--border": `hsl(${c.border})`,
    "--input": `hsl(${c.input})`,
    "--ring": `hsl(${c.ring})`,
    "--destructive": `hsl(${c.destructive})`,
    "--destructive-foreground": `hsl(${c.destructiveForeground})`,
  };
}

export function applyTheme(theme: ThemeState, effectiveDark: boolean) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const vars = colorVars(effectiveDark ? theme.darkColors : theme.colors);
  for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v);

  root.style.setProperty("--sidebar", effectiveDark ? "hsl(240 10% 6%)" : "hsl(0 0% 100%)");
  root.style.setProperty("--sidebar-foreground", effectiveDark ? "hsl(0 0% 95%)" : "hsl(240 10% 3.9%)");
  root.style.setProperty("--sidebar-primary", `hsl(${(effectiveDark ? theme.darkColors : theme.colors).primary})`);
  root.style.setProperty("--sidebar-primary-foreground", `hsl(${(effectiveDark ? theme.darkColors : theme.colors).primaryForeground})`);
  root.style.setProperty("--sidebar-accent", effectiveDark ? "hsl(240 6% 14%)" : "hsl(240 4.8% 95.9%)");
  root.style.setProperty("--sidebar-accent-foreground", effectiveDark ? "hsl(0 0% 98%)" : "hsl(240 5.9% 10%)");
  root.style.setProperty("--sidebar-border", effectiveDark ? "hsl(240 6% 14%)" : "hsl(240 5.9% 90%)");
  root.style.setProperty("--sidebar-ring", `hsl(${(effectiveDark ? theme.darkColors : theme.colors).ring})`);
  root.style.setProperty("--radius", `${theme.radius}rem`);
  root.style.setProperty("--font-sans", theme.font.family);
  root.style.fontSize = `${16 * theme.font.scale}px`;

  root.classList.toggle("dark", effectiveDark);
  root.dataset.theme = theme.preset;
  root.dataset.sidebar = theme.sidebarVariant;
  root.dataset.content = theme.contentWidth;
  root.dataset.layout = theme.layout;
}

function isThemeColors(value: unknown): value is ThemeColors {
  if (!value || typeof value !== "object") return false;
  const keys: (keyof ThemeColors)[] = ["primary", "primaryForeground", "secondary", "secondaryForeground", "accent", "accentForeground", "background", "foreground", "card", "cardForeground", "muted", "mutedForeground", "border", "input", "ring", "destructive", "destructiveForeground"];
  return keys.every((key) => {
    const token = (value as Record<string, unknown>)[key];
    if (typeof token !== "string") return false;
    const match = token.match(HSL_TOKEN_PATTERN);
    if (!match) return false;
    const [, hue, saturation, lightness] = match.map(Number);
    return Number.isFinite(hue) && Number.isFinite(saturation) && Number.isFinite(lightness)
      && hue >= 0 && hue <= 360 && saturation >= 0 && saturation <= 100
      && lightness >= 0 && lightness <= 100;
  });
}

function normalizeTheme(value: unknown): ThemeState | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value as Partial<ThemeState>;
  if (!isThemeColors(candidate.colors) || !isThemeColors(candidate.darkColors)) return null;
  if (!candidate.font || typeof candidate.font.family !== "string" || !FONT_FAMILY_ALLOWLIST.has(candidate.font.family)) return null;
  if (!Number.isFinite(candidate.font.scale) || candidate.font.scale! < 0.85 || candidate.font.scale! > 1.2) return null;
  if (!Number.isFinite(candidate.radius) || candidate.radius! < 0 || candidate.radius! > 1.5) return null;
  if (!["light", "dark", "system"].includes(candidate.mode ?? "")) return null;
  if (!["default", "floating", "inset"].includes(candidate.sidebarVariant ?? "")) return null;
  if (!["default", "icon", "full"].includes(candidate.sidebarMode ?? "default")) return null;
  if (candidate.layout !== undefined && !["default", "full-navbar", "horizontal", "split", "icon-menu", "paper", "adaptive"].includes(candidate.layout)) return null;
  if (!["full", "compact", "boxed"].includes(candidate.contentWidth ?? "")) return null;
  if (candidate.preset !== "custom" && !PRESET_THEMES.some((preset) => preset.name === candidate.preset)) return null;
  const storedContentWidth = (candidate as Record<string, unknown>).contentWidth;
  return { ...DEFAULT_THEME, ...candidate, sidebarMode: candidate.sidebarMode ?? "default", layout: candidate.layout ?? "default", contentWidth: storedContentWidth === "boxed" ? "compact" : (candidate.contentWidth ?? "full"), font: { family: candidate.font.family, scale: candidate.font.scale! } };
}

const FONT_FAMILY_ALLOWLIST = new Set(FONT_OPTIONS.map((font) => font.value));

function loadStored(): ThemeState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return normalizeTheme(JSON.parse(raw)) ?? DEFAULT_THEME;
  } catch {
    /* ignore */
  }
  return DEFAULT_THEME;
}

function getSystemDark(): boolean {
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
}

interface ThemeContextValue {
  theme: ThemeState;
  effectiveDark: boolean;
  update: (patch: Partial<ThemeState>) => void;
  applyPreset: (name: string) => void;
  reset: () => void;
  exportTheme: () => string;
  importTheme: (json: string) => boolean;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<ThemeState>(loadStored);
  const [systemDark, setSystemDark] = useState<boolean>(getSystemDark);

  useEffect(() => {
    if (typeof window.matchMedia !== "function") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const fn = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener?.("change", fn);
    return () => mq.removeEventListener?.("change", fn);
  }, []);

  const effectiveDark = theme.mode === "system" ? systemDark : theme.mode === "dark";

  useEffect(() => {
    applyTheme(theme, effectiveDark);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(theme));
    } catch {
      // The current session remains usable when browser storage is unavailable.
    }
  }, [theme, effectiveDark]);

  const value = useMemo<ThemeContextValue>(
    () => ({
      theme,
      effectiveDark,
      update: (patch) => setTheme((t) => ({ ...t, ...patch })),
      applyPreset: (name) => {
        const p = PRESET_THEMES.find((x) => x.name === name);
        if (!p) return;
        setTheme((t) => ({ ...t, preset: p.name, colors: p.colors, darkColors: p.darkColors }));
      },
      reset: () => setTheme(DEFAULT_THEME),
      exportTheme: () => JSON.stringify(theme, null, 2),
      importTheme: (json) => {
        try {
          const parsed = normalizeTheme(JSON.parse(json));
          if (!parsed) return false;
          setTheme(parsed);
          return true;
        } catch {
          return false;
        }
      },
    }),
    [theme, effectiveDark],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
