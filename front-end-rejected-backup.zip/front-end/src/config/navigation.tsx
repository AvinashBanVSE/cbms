import {
  Building2,
  FileText,
  Landmark,
  ScrollText,
  Settings,
  ShieldCheck,
  UserCog,
  Users,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface NavigationItem {
  label: string;
  to: string;
  icon: LucideIcon;
  end?: boolean;
}

export interface NavigationGroup {
  label: string;
  items: NavigationItem[];
}

export const navigationGroups: NavigationGroup[] = [
  {
    label: "Workspace",
    items: [
      { label: "Services", to: "/workspace/services", icon: Landmark, end: true },
      { label: "Businesses", to: "/workspace/businesses", icon: Building2 },
      { label: "Legal Identities", to: "/workspace/identities", icon: FileText },
    ],
  },
  {
    label: "Administration",
    items: [
      { label: "Organization Users", to: "/workspace/users", icon: Users },
      { label: "Commercial", to: "/workspace/commercial", icon: ScrollText },
      { label: "Audit Trail", to: "/workspace/audit", icon: ShieldCheck },
      { label: "Sub-Portal Users", to: "/workspace/provider-users", icon: UserCog },
      { label: "Business Settings", to: "/workspace/business-settings", icon: Settings },
    ],
  },
];

export const navigationItems = navigationGroups.flatMap((group) => group.items);
