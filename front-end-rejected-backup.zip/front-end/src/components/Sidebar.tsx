import { NavLink } from "react-router-dom";
import { ChevronLeft, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { navigationGroups, navigationItems } from "@/config/navigation";
import type { DashboardLayout, SidebarMode } from "@/theme/presets";

interface SidebarProps {
  open: boolean;
  collapsed: boolean;
  mode: SidebarMode;
  layout: DashboardLayout;
  onClose: () => void;
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className={cn("flex h-16 shrink-0 items-center gap-3 border-b border-sidebar-border px-5", compact && "justify-center px-2")}>
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sidebar-primary text-sm font-bold text-sidebar-primary-foreground">C</div>
      {!compact && <span className="text-base font-semibold tracking-tight">CBMS Admin</span>}
    </div>
  );
}

function UserFooter({ compact = false }: { compact?: boolean }) {
  return (
    <div className={cn("border-t border-sidebar-border p-4", compact && "px-2")}>
      <div className={cn("flex items-center gap-3", compact && "justify-center")}>
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sidebar-primary text-xs font-bold text-sidebar-primary-foreground">CB</div>
        {!compact && <div className="min-w-0"><p className="truncate text-sm font-medium">CBMS User</p><p className="truncate text-xs text-sidebar-foreground/60">Main Portal</p></div>}
        {!compact && <ChevronLeft className="ml-auto h-4 w-4 text-sidebar-foreground/50" />}
      </div>
    </div>
  );
}

export function Sidebar({ open, collapsed, mode, layout, onClose }: SidebarProps) {
  const isIconMenu = layout === "icon-menu";
  const isSplit = layout === "split";
  const iconOnly = isIconMenu || (collapsed && !isSplit);

  return (
    <>
      {open && <button aria-label="Close navigation" className="fixed inset-0 z-30 bg-black/40 md:hidden" onClick={onClose} />}
      <aside
        aria-label="Application sidebar"
        className={cn(
          "app-sidebar fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-all duration-200",
          !isSplit && iconOnly && "md:w-[4.5rem]",
          !isSplit && mode === "full" && !isIconMenu && "md:w-72",
          isSplit && "md:w-[17rem]",
          open ? "translate-x-0" : "-translate-x-full md:translate-x-0",
          isIconMenu && "app-sidebar-icon-menu",
          isSplit && "app-sidebar-split",
          layout === "adaptive" && "app-sidebar-adaptive",
        )}
      >
        {isSplit ? (
          <div className="flex min-h-0 flex-1">
            <nav aria-label="Quick navigation" className="flex w-[4.25rem] shrink-0 flex-col items-center gap-2 border-r border-sidebar-border py-3">
              <div className="mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-sidebar-primary text-sm font-bold text-sidebar-primary-foreground">C</div>
              {navigationItems.map((item) => (
                <NavLink key={item.to} to={item.to} end={item.end} onClick={onClose} title={item.label} aria-label={item.label}
                  className={({ isActive }) => cn("flex h-10 w-10 items-center justify-center rounded-xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring", isActive ? "bg-sidebar-primary text-sidebar-primary-foreground" : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground")}>
                  <item.icon className="h-[18px] w-[18px]" />
                </NavLink>
              ))}
              <div className="mt-auto"><div className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-primary text-xs font-bold text-sidebar-primary-foreground">AV</div></div>
            </nav>
            <div className="flex min-w-0 flex-1 flex-col">
              <div className="flex h-16 shrink-0 items-center border-b border-sidebar-border px-4"><span className="truncate text-sm font-semibold">CBMS Workspace</span><button className="ml-auto rounded-md p-1 hover:bg-sidebar-accent md:hidden" aria-label="Close navigation" onClick={onClose}><X className="h-4 w-4" /></button></div>
              <nav aria-label="Workspace navigation" className="flex-1 space-y-6 overflow-y-auto px-3 py-5">
                {navigationGroups.map((group) => (
                  <div key={group.label} className="space-y-2">
                    <p className="px-2 text-[10px] font-semibold uppercase tracking-[0.12em] text-sidebar-foreground/50">{group.label}</p>
                    {group.items.map((item) => (
                      <NavLink key={item.to} to={item.to} end={item.end} onClick={onClose}
                        className={({ isActive }) => cn("flex min-h-9 items-center rounded-lg px-2.5 py-2 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring", isActive ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground")}>
                        {item.label}
                      </NavLink>
                    ))}
                  </div>
                ))}
              </nav>
              <UserFooter />
            </div>
          </div>
        ) : (
          <>
            <Brand compact={iconOnly} />
            <button className="absolute right-3 top-5 rounded-md p-1 hover:bg-sidebar-accent md:hidden" aria-label="Close navigation" onClick={onClose}><X className="h-4 w-4" /></button>
            <nav aria-label="Main navigation" className={cn("flex-1 space-y-7 overflow-y-auto px-3 py-5", iconOnly && "md:px-2")}>
              {navigationGroups.map((group) => (
                <div key={group.label} className="space-y-2">
                  <p className={cn("px-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-sidebar-foreground/50", iconOnly && "md:hidden")}>{group.label}</p>
                  {group.items.map((item) => (
                    <NavLink key={item.to} to={item.to} end={item.end} onClick={onClose}
                      title={iconOnly || layout === "adaptive" ? item.label : undefined}
                      aria-label={iconOnly || layout === "adaptive" ? item.label : undefined}
                      className={({ isActive }) => cn(
                        "flex min-h-10 items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring",
                        iconOnly && "md:justify-center md:px-2",
                        isActive ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                      )}>
                      <item.icon className="h-[18px] w-[18px] shrink-0" />
                      <span className={cn(iconOnly && "md:hidden")}>{item.label}</span>
                    </NavLink>
                  ))}
                </div>
              ))}
            </nav>
            <UserFooter compact={iconOnly} />
          </>
        )}
      </aside>
    </>
  );
}
