import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Search, Bell, Palette, Menu, Command, X, CheckCheck, PanelLeft,
  UserRound, Settings, ChevronDown, SunMoon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { ThemeEditor } from "@/components/ThemeEditor";
import type { DashboardLayout } from "@/theme/presets";

import { navigationItems } from "@/config/navigation";

const pages = navigationItems.map((item) => ({
  title: item.label,
  path: item.to,
  keywords: item.label.toLowerCase(),
}));
const titles: Record<string, string> = Object.fromEntries(pages.map((page) => [page.path, page.title]));

interface HeaderProps { onMenuClick: () => void; onCollapseClick: () => void; layout: DashboardLayout; hasSidebar: boolean; navigationOpen: boolean; canCollapseSidebar: boolean }

export function Header({ onMenuClick, onCollapseClick, layout, hasSidebar, navigationOpen, canCollapseSidebar }: HeaderProps) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const title = titles[pathname] ?? "CBMS Workspace";
  const [themeOpen, setThemeOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [readNotifications, setReadNotifications] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);

  const closeThemeEditor = useCallback(() => setThemeOpen(false), []);

  const filteredPages = useMemo(
    () => pages.filter((page) => `${page.title} ${page.keywords}`.toLowerCase().includes(query.trim().toLowerCase())),
    [query],
  );

  useEffect(() => {
    setProfileOpen(false);
    setNotificationsOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onPointerDown = (event: PointerEvent) => {
      const target = event.target as Node;
      if (!profileRef.current?.contains(target)) setProfileOpen(false);
      if (!notificationsRef.current?.contains(target)) setNotificationsOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommandOpen((open) => !open);
      }
      if (event.key === "Escape") {
        setCommandOpen(false);
        setNotificationsOpen(false);
        setProfileOpen(false);
      }
    };
    document.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, []);

  const goTo = (path: string) => {
    navigate(path);
    setCommandOpen(false);
    setQuery("");
    setProfileOpen(false);
    setNotificationsOpen(false);
  };

  return (
    <>
      <header data-header-layout={layout} className="app-header sticky top-0 z-30 flex h-16 w-full min-w-0 items-center justify-between gap-2 border-b bg-background/95 px-3 backdrop-blur supports-[backdrop-filter]:bg-background/80 sm:gap-3 sm:px-6">
        <div className="flex min-w-0 flex-1 items-center gap-2 sm:gap-3">
          <Button variant="ghost" size="icon" className="shrink-0 md:hidden" aria-label={hasSidebar ? "Toggle navigation" : "Toggle menu"} aria-expanded={navigationOpen} onClick={onMenuClick}>
            <Menu className="h-5 w-5" />
          </Button>
          {canCollapseSidebar && <Button variant="ghost" size="icon" className="hidden shrink-0 md:inline-flex" aria-label="Toggle sidebar width" onClick={onCollapseClick}>
            <PanelLeft className="h-4 w-4" />
          </Button>}
          <div className="min-w-0">
            <h1 className="truncate text-base font-semibold tracking-tight sm:text-lg">{title}</h1>
            <p className="hidden text-xs text-muted-foreground sm:block">Welcome back</p>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-0.5 sm:gap-1.5">
          <Button variant="outline" className="hidden h-9 w-52 justify-start px-3 text-muted-foreground lg:inline-flex xl:w-60" onClick={() => setCommandOpen(true)}>
            <Search className="mr-2 h-4 w-4" /><span className="flex-1 text-left text-xs">Search pages...</span>
            <kbd className="rounded border bg-muted px-1.5 py-0.5 text-[10px]">⌘ K</kbd>
          </Button>
          <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Search pages" onClick={() => setCommandOpen(true)}>
            <Search className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" aria-label="Open theme customizer" aria-expanded={themeOpen} onClick={() => setThemeOpen(true)}>
            <Palette className="h-4 w-4" />
          </Button>

          <div className="relative" ref={notificationsRef}>
            <Button variant="ghost" size="icon" aria-label="Notifications" aria-expanded={notificationsOpen} onClick={() => { setNotificationsOpen((open) => !open); setProfileOpen(false); }}>
              <Bell className="h-4 w-4" />
              {!readNotifications && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-destructive ring-2 ring-background" />}
            </Button>
            {notificationsOpen && (
              <div className="absolute right-0 top-12 z-50 w-[min(20rem,calc(100vw-1.5rem))] rounded-xl border bg-popover p-4 text-popover-foreground shadow-xl" role="dialog" aria-label="Notifications">
                <div className="mb-3 flex items-center justify-between gap-2">
                  <p className="font-semibold">Notifications</p>
                  <button className="inline-flex items-center text-xs text-primary hover:underline" onClick={() => setReadNotifications(true)}>
                    <CheckCheck className="mr-1 h-3 w-3" />Mark all read
                  </button>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="rounded-lg bg-muted/60 p-3"><p className="font-medium">Workspace ready</p><p className="mt-1 text-xs text-muted-foreground">Portal sections are available in the sidebar.</p></div>
                  <div className="rounded-lg p-3"><p className="font-medium">Theme customization</p><p className="mt-1 text-xs text-muted-foreground">Personalize colors and layout from Theme Customizer.</p></div>
                </div>
                <Button variant="ghost" size="sm" className="mt-2 w-full" onClick={() => setNotificationsOpen(false)}>Close</Button>
              </div>
            )}
          </div>

          <div className="relative" ref={profileRef}>
            <Button
              variant="ghost"
              className="h-10 gap-2 rounded-full px-1.5 sm:px-2"
              aria-label="Open user menu"
              aria-haspopup="menu"
              aria-expanded={profileOpen}
              onClick={() => { setProfileOpen((open) => !open); setNotificationsOpen(false); }}
            >
              <Avatar className="h-8 w-8"><AvatarFallback className="bg-primary text-primary-foreground">CB</AvatarFallback></Avatar>
              <span className="hidden max-w-24 text-left text-sm font-medium sm:block">CBMS User</span>
              <ChevronDown className="hidden h-3.5 w-3.5 text-muted-foreground sm:block" />
            </Button>
            {profileOpen && (
              <div className="absolute right-0 top-12 z-50 w-60 overflow-hidden rounded-xl border bg-popover text-popover-foreground shadow-xl" role="menu" aria-label="User account menu">
                <div className="border-b px-3 py-3">
                  <p className="text-sm font-semibold">CBMS User</p>
                  <p className="truncate text-xs text-muted-foreground">Administrator · Main Portal</p>
                </div>
                <div className="p-1.5">
                  <button role="menuitem" className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-sm hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => goTo("/workspace/business-settings")}>
                    <UserRound className="h-4 w-4" />Profile & account
                  </button>
                  <button role="menuitem" className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-sm hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => goTo("/workspace/business-settings")}>
                    <Settings className="h-4 w-4" />Settings
                  </button>
                  <button role="menuitem" className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-sm hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => { setProfileOpen(false); setThemeOpen(true); }}>
                    <SunMoon className="h-4 w-4" />Appearance
                  </button>
                  <div className="my-1 border-t" />
                  <button role="menuitem" className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-sm text-muted-foreground hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => setProfileOpen(false)}>
                    <X className="h-4 w-4" />Close menu
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {commandOpen && (
        <div className="fixed inset-0 z-[70] flex items-start justify-center bg-black/45 px-4 pt-[12vh]" onMouseDown={(event) => { if (event.target === event.currentTarget) setCommandOpen(false); }}>
          <section role="dialog" aria-modal="true" aria-label="Search pages" className="w-full max-w-lg overflow-hidden rounded-xl border bg-popover text-popover-foreground shadow-2xl">
            <div className="flex items-center gap-2 border-b px-4"><Search className="h-4 w-4 text-muted-foreground" /><Input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search pages and navigation..." className="h-12 border-0 shadow-none focus-visible:ring-0" /><Button variant="ghost" size="icon" aria-label="Close search" onClick={() => setCommandOpen(false)}><X className="h-4 w-4" /></Button></div>
            <div className="max-h-72 overflow-y-auto p-2">{filteredPages.length ? filteredPages.map((page) => <button key={page.path} onClick={() => goTo(page.path)} className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><span>{page.title}</span><Command className="h-3.5 w-3.5 text-muted-foreground" /></button>) : <p className="p-5 text-center text-sm text-muted-foreground">No matching pages found.</p>}</div>
            <div className="border-t px-4 py-2 text-[11px] text-muted-foreground">Navigate using the search results · Esc to close</div>
          </section>
        </div>
      )}
      {themeOpen && <ThemeEditor onClose={closeThemeEditor} />}
    </>
  );
}
