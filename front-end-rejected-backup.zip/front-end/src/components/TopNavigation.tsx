import { NavLink } from "react-router-dom";
import { navigationItems } from "@/config/navigation";
import type { DashboardLayout } from "@/theme/presets";
import { cn } from "@/lib/utils";

interface TopNavigationProps {
  variant: Extract<DashboardLayout, "full-navbar" | "horizontal">;
  mobileOpen: boolean;
  onNavigate: () => void;
}

export function TopNavigation({ variant, mobileOpen, onNavigate }: TopNavigationProps) {
  const isHorizontal = variant === "horizontal";

  return (
    <div className={cn(
      "top-navigation relative z-20 w-full border-b bg-background",
      isHorizontal ? "border-b-0" : "bg-card/95",
      isHorizontal && "horizontal-navigation",
      !isHorizontal && "full-navbar-navigation",
    )}>
      <div className={cn("mx-auto flex min-h-14 w-full items-center gap-4 px-4 sm:px-6", isHorizontal && "min-h-[4.25rem] border-b")}>
        {isHorizontal && (
          <div className="flex shrink-0 items-center gap-2.5 pr-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-sm font-bold text-primary-foreground">C</span>
            <span className="hidden text-sm font-semibold tracking-tight sm:inline">CBMS Workspace</span>
          </div>
        )}
        <nav aria-label="Primary navigation" className={cn("hidden min-w-0 flex-1 items-center gap-1 overflow-x-auto md:flex", isHorizontal && "gap-1.5")}>
          {navigationItems.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} onClick={onNavigate}
              className={({ isActive }) => cn(
                "inline-flex min-h-9 shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                isHorizontal
                  ? isActive ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  : isActive ? "border-b-2 border-primary rounded-none text-primary" : "border-b-2 border-transparent rounded-none text-muted-foreground hover:text-foreground",
              )}>
              <item.icon className="h-4 w-4" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
        {isHorizontal && <span className="ml-auto hidden text-xs text-muted-foreground lg:block">Business Management Workspace</span>}
      </div>
      {mobileOpen && (
        <nav aria-label="Mobile primary navigation" className="grid grid-cols-2 gap-1 border-t p-3 md:hidden">
          {navigationItems.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} onClick={onNavigate}
              className={({ isActive }) => cn("flex min-h-10 items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium", isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground")}>
              <item.icon className="h-4 w-4" />{item.label}
            </NavLink>
          ))}
        </nav>
      )}
    </div>
  );
}
