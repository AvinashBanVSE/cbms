import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { Check, Download, Palette, RotateCcw, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useTheme, hslToHex, hslToHslString } from "@/theme/ThemeProvider";
import { FONT_OPTIONS, PRESET_THEMES } from "@/theme/presets";
import type { ContentWidth, DashboardLayout, SidebarVariant, ThemeColors, ThemeMode } from "@/theme/presets";

function ColorField({
  label,
  varName,
  value,
  onChange,
}: {
  label: string;
  varName: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <input
        type="color"
        aria-label={`${label} theme color`}
        className="h-7 w-7 cursor-pointer rounded border bg-card"
        value={hslToHex(value)}
        onChange={(e) => {
          const hex = e.target.value;
          const r = parseInt(hex.slice(1, 3), 16) / 255;
          const g = parseInt(hex.slice(3, 5), 16) / 255;
          const b = parseInt(hex.slice(5, 7), 16) / 255;
          const max = Math.max(r, g, b);
          const min = Math.min(r, g, b);
          let h = 0, s = 0;
          const l = (max + min) / 2;
          if (max !== min) {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) * 60;
            else if (max === g) h = ((b - r) / d + 2) * 60;
            else h = ((r - g) / d + 4) * 60;
          }
          onChange(`${Math.round(h)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`);
        }}
      />
      <span className="flex-1">{label}</span>
      <code className="text-[10px] text-muted-foreground">{hslToHslString(value)}</code>
      <span className="sr-only">{varName}</span>
    </label>
  );
}


const LAYOUT_OPTIONS: { value: DashboardLayout; label: string; description: string }[] = [
  { value: "default", label: "Default", description: "Classic left sidebar" },
  { value: "full-navbar", label: "Full Navbar", description: "Full-width navigation bar" },
  { value: "horizontal", label: "Horizontal", description: "Brand and horizontal menu" },
  { value: "split", label: "Split", description: "Icon rail + navigation panel" },
  { value: "icon-menu", label: "Icon Menu", description: "Compact icon-only sidebar" },
  { value: "paper", label: "Paper", description: "Framed workspace canvas" },
  { value: "adaptive", label: "Adaptive", description: "Responsive sidebar density" },
];

function LayoutPreview({ layout }: { layout: DashboardLayout }) {
  const sidebar = ["default", "paper", "adaptive"].includes(layout);
  const split = layout === "split";
  const iconMenu = layout === "icon-menu";
  const top = layout === "full-navbar" || layout === "horizontal";
  return (
    <div aria-hidden="true" className={`layout-preview relative h-[58px] overflow-hidden rounded-md border bg-muted/70 p-1.5 ${layout === "paper" ? "ring-1 ring-foreground/20" : ""}`}>
      {top && <div className={`mb-1 flex h-2.5 items-center gap-1 rounded-sm ${layout === "horizontal" ? "bg-card" : "bg-primary/15"}`}>
        {layout === "horizontal" && <span className="h-2 w-2 rounded-sm bg-primary" />}
        <span className="h-1 w-5 rounded-full bg-foreground/35" />
        <span className="h-1 w-3 rounded-full bg-foreground/20" />
        <span className="h-1 w-3 rounded-full bg-foreground/20" />
        <span className="h-1 w-3 rounded-full bg-foreground/20" />
      </div>}
      <div className="flex h-[calc(100%-0.875rem)] min-h-0 gap-1">
        {sidebar && <div className={`flex shrink-0 flex-col gap-1 rounded-sm bg-card p-1 ${layout === "adaptive" ? "w-3/12" : "w-4/12"}`}>
          <span className="h-1 w-4 rounded-full bg-primary/70" />
          <span className="h-1 w-full rounded-full bg-foreground/20" />
          <span className="h-1 w-4/5 rounded-full bg-foreground/20" />
          <span className="h-1 w-full rounded-full bg-foreground/20" />
        </div>}
        {split && <><div className="flex w-2 shrink-0 flex-col gap-1 rounded-sm bg-primary/25 p-0.5"><span className="h-1.5 rounded-sm bg-primary"/><span className="h-1.5 rounded-sm bg-foreground/25"/><span className="h-1.5 rounded-sm bg-foreground/25"/></div><div className="flex w-4/12 shrink-0 flex-col gap-1 rounded-sm bg-card p-1"><span className="h-1 w-4 rounded-full bg-primary/70"/><span className="h-1 w-full rounded-full bg-foreground/20"/><span className="h-1 w-3/4 rounded-full bg-foreground/20"/></div></>}
        {iconMenu && <div className="flex w-3 shrink-0 flex-col items-center gap-1 rounded-sm bg-card p-1"><span className="h-1.5 w-1.5 rounded-sm bg-primary"/><span className="h-1.5 w-1.5 rounded-sm bg-foreground/30"/><span className="h-1.5 w-1.5 rounded-sm bg-foreground/30"/><span className="h-1.5 w-1.5 rounded-sm bg-foreground/30"/></div>}
        <div className="flex min-w-0 flex-1 flex-col gap-1 rounded-sm bg-card p-1">
          <span className="h-1 w-1/3 rounded-full bg-foreground/35" />
          <div className="grid flex-1 grid-cols-2 gap-1"><span className="rounded-sm border bg-background"/><span className="rounded-sm border bg-background"/></div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold">{title}</h3>
      {children}
    </div>
  );
}

export function ThemeEditor({ onClose }: { onClose: () => void }) {
  const { theme, effectiveDark, update, applyPreset, reset, exportTheme, importTheme } = useTheme();
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [importMsg, setImportMsg] = useState<string | null>(null);
  const panelRef = useRef<HTMLElement | null>(null);

  const active: ThemeColors = effectiveDark ? theme.darkColors : theme.colors;

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    document.body.style.overflow = "hidden";
    panelRef.current?.querySelector<HTMLElement>("button, input, select, textarea")?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key === "Tab" && panelRef.current) {
        const items = Array.from(panelRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ));
        if (!items.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
      previouslyFocused?.focus();
    };
  }, [onClose]);
  const setColor = (key: keyof ThemeColors, val: string) => {
    if (effectiveDark) update({ preset: "custom", darkColors: { ...theme.darkColors, [key]: val } });
    else update({ preset: "custom", colors: { ...theme.colors, [key]: val } });
  };

  const handleExport = () => {
    const blob = new Blob([exportTheme()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cbms-theme.json";
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const handleImport = () => {
    const ok = importTheme(importText);
    setImportMsg(ok ? "Theme imported successfully" : "Invalid theme JSON");
    if (ok) setTimeout(() => { setImportOpen(false); setImportMsg(null); }, 1200);
  };

  return (
    <>
      <button type="button" className="fixed inset-0 z-40 cursor-default bg-black/45 backdrop-blur-[1px]" onClick={onClose} aria-label="Close theme customizer" />
      <section role="dialog" aria-modal="true" aria-labelledby="theme-editor-title" ref={panelRef} className="fixed inset-y-0 right-0 z-50 flex w-full max-w-[440px] flex-col border-l bg-background text-foreground shadow-2xl">
        <div className="flex h-16 shrink-0 items-center justify-between border-b px-5">
          <div className="flex items-center gap-2">
            <Palette className="h-5 w-5" />
            <div><h2 id="theme-editor-title" className="text-lg font-semibold">Theme Customizer</h2><p className="text-xs text-muted-foreground">Personalize your dashboard appearance</p></div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close theme customizer">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto p-5">
          <div className="rounded-xl border bg-card p-3">
            <div className="mb-3 flex items-center justify-between"><span className="text-xs font-medium text-muted-foreground">LIVE PREVIEW</span><span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">{effectiveDark ? "Dark" : "Light"} mode</span></div>
            <div className="flex items-center gap-2 rounded-lg border bg-background p-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary text-xs font-bold text-primary-foreground">C</span>
              <div className="min-w-0 flex-1"><div className="h-2 w-20 rounded bg-foreground/80"/><div className="mt-1.5 h-1.5 w-14 rounded bg-muted-foreground/40"/></div>
              <span className="h-6 w-6 rounded-full border-2 border-primary bg-primary/15"/>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2"><div className="rounded-lg border bg-background p-2"><div className="text-[10px] text-muted-foreground">Revenue</div><div className="mt-1 text-sm font-semibold">$24,560</div></div><div className="rounded-lg border bg-background p-2"><div className="text-[10px] text-muted-foreground">Growth</div><div className="mt-1 text-sm font-semibold text-primary">+12.8%</div></div></div>
          </div>
          <Section title="Dashboard Layout">
            <p className="-mt-1 text-xs text-muted-foreground">Switch the complete application structure instantly. Your selection is saved automatically.</p>
            <div className="grid grid-cols-2 gap-2">
              {LAYOUT_OPTIONS.map((option) => {
                const selected = theme.layout === option.value;
                return (
                  <button
                    key={option.value}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => update({ layout: option.value })}
                    className={`group rounded-lg border p-2 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${selected ? "border-primary bg-primary/5 ring-1 ring-primary" : "hover:border-primary/50 hover:bg-muted/50"}`}
                    title={`Use ${option.label} layout`}
                  >
                    <div className="relative">
                      <LayoutPreview layout={option.value} />
                      {selected && <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground shadow"><Check className="h-3 w-3" /></span>}
                    </div>
                    <span className="mt-2 block text-xs font-semibold">{option.label}</span>
                    <span className="mt-0.5 block text-[10px] leading-4 text-muted-foreground">{option.description}</span>
                  </button>
                );
              })}
            </div>
          </Section>
          {/* Mode */}
          <Section title="Mode">
            <div className="grid grid-cols-3 gap-2">
              {(["light", "dark", "system"] as ThemeMode[]).map((m) => (
                <Button
                  key={m}
                  variant={theme.mode === m ? "default" : "outline"}
                  size="sm"
                  className="capitalize"
                  onClick={() => update({ mode: m })}
                >
                  {m}
                </Button>
              ))}
            </div>
          </Section>

          {/* Presets */}
          <Section title="Preset Themes">
            <div className="grid grid-cols-5 gap-2">
              {PRESET_THEMES.map((p) => (
                <button
                  key={p.name}
                  onClick={() => applyPreset(p.name)}
                  className="group flex flex-col items-center gap-1"
                  title={p.label}
                  aria-label={`Apply ${p.label} theme`}
                >
                  <span
                    className="relative flex h-9 w-9 items-center justify-center rounded-full ring-2 ring-offset-2 ring-offset-background"
                    style={{ background: p.swatch, boxShadow: theme.preset === p.name ? "0 0 0 2px var(--primary)" : undefined }}
                  >
                    {theme.preset === p.name && <Check className="h-4 w-4 text-white" />}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{p.label}</span>
                </button>
              ))}
            </div>
          </Section>

          {/* Custom Colors */}
          <Section title="Custom Colors">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <ColorField label="Primary" varName="primary" value={active.primary} onChange={(v) => setColor("primary", v)} />
              <ColorField label="Background" varName="background" value={active.background} onChange={(v) => setColor("background", v)} />
              <ColorField label="Card" varName="card" value={active.card} onChange={(v) => setColor("card", v)} />
              <ColorField label="Foreground" varName="foreground" value={active.foreground} onChange={(v) => setColor("foreground", v)} />
              <ColorField label="Secondary" varName="secondary" value={active.secondary} onChange={(v) => setColor("secondary", v)} />
              <ColorField label="Muted" varName="muted" value={active.muted} onChange={(v) => setColor("muted", v)} />
              <ColorField label="Accent" varName="accent" value={active.accent} onChange={(v) => setColor("accent", v)} />
              <ColorField label="Border" varName="border" value={active.border} onChange={(v) => setColor("border", v)} />
              <ColorField label="Destructive" varName="destructive" value={active.destructive} onChange={(v) => setColor("destructive", v)} />
              <ColorField label="Ring" varName="ring" value={active.ring} onChange={(v) => setColor("ring", v)} />
            </div>
          </Section>

          <Separator />

          {/* Font */}
          <Section title="Font">
            <Select
              value={theme.font.family}
              onValueChange={(v) => update({ font: { ...theme.font, family: v } })}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {FONT_OPTIONS.map((f) => (
                  <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Section>

          {/* Radius */}
          <Section title={`Radius — ${theme.radius.toFixed(2)}rem`}>
            <input
              type="range" min="0" max="1.5" step="0.05"
              aria-label="Corner radius"
              value={theme.radius}
              onChange={(e) => update({ radius: parseFloat(e.target.value) })}
              className="w-full accent-[var(--primary)]"
            />
          </Section>

          {/* Scale */}
          <Section title={`Scale — ${Math.round(theme.font.scale * 100)}%`}>
            <input
              type="range" min="0.85" max="1.2" step="0.05"
              aria-label="Font scale"
              value={theme.font.scale}
              onChange={(e) => update({ font: { ...theme.font, scale: parseFloat(e.target.value) } })}
              className="w-full accent-[var(--primary)]"
            />
          </Section>

          {(["default", "paper", "adaptive"].includes(theme.layout)) && <Section title="Sidebar Variant">
            <div className="grid grid-cols-3 gap-2">
              {(["default", "floating", "inset"] as SidebarVariant[]).map((v) => (
                <Button
                  key={v}
                  variant={theme.sidebarVariant === v ? "default" : "outline"}
                  size="sm"
                  className="capitalize"
                  onClick={() => update({ sidebarVariant: v })}
                >
                  {v}
                </Button>
              ))}
            </div>
          </Section>}

          {(["default", "paper"].includes(theme.layout)) && <Section title="Sidebar Mode">
            <div className="grid grid-cols-3 gap-2">
              {(["default", "icon", "full"] as const).map((v) => (
                <Button key={v} variant={theme.sidebarMode === v ? "default" : "outline"} size="sm" className="capitalize" onClick={() => update({ sidebarMode: v })}>
                  {v === "default" ? "Default" : v === "icon" ? "Icon" : "Full"}
                </Button>
              ))}
            </div>
          </Section>}

          {/* Content Width */}
          <Section title="Content Width">
            <div className="grid grid-cols-2 gap-2">
              {(["full", "compact"] as ContentWidth[]).map((v) => (
                <Button
                  key={v}
                  variant={theme.contentWidth === v ? "default" : "outline"}
                  size="sm"
                  className="capitalize"
                  onClick={() => update({ contentWidth: v })}
                >
                  {v}
                </Button>
              ))}
            </div>
          </Section>
        </div>

        <div className="shrink-0 space-y-3 border-t p-5">
          {importOpen ? (
            <div className="space-y-2">
              <textarea
                aria-label="Theme JSON to import"
                placeholder="Paste exported theme JSON here..."
                value={importText}
                onChange={(e) => setImportText(e.target.value)}
                rows={5}
                className="w-full resize-y rounded-md border border-input bg-background px-3 py-2 font-mono text-xs shadow-sm outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
              <div className="flex gap-2">
                <Button size="sm" className="flex-1" onClick={handleImport}>Import</Button>
                <Button size="sm" variant="outline" onClick={() => { setImportOpen(false); setImportMsg(null); }}>Cancel</Button>
              </div>
              {importMsg && <p className="text-xs text-muted-foreground">{importMsg}</p>}
            </div>
          ) : (
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="flex-1" onClick={() => setImportOpen(true)}>
                <Upload className="mr-1 h-3 w-3" /> Import
              </Button>
              <Button size="sm" variant="outline" className="flex-1" onClick={handleExport}>
                <Download className="mr-1 h-3 w-3" /> Export
              </Button>
            </div>
          )}
          <Button size="sm" variant="ghost" className="w-full" onClick={reset}>
            <RotateCcw className="mr-1 h-3 w-3" /> Reset to Default
          </Button>
        </div>
      </section>
    </>
  );
}
