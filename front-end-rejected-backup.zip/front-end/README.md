# CBMS Admin Dashboard

A Vite + React + TypeScript admin dashboard prototype.

## Requirements

- Node.js 20.19+ or 22.12+
- npm

## Run locally

```bash
npm ci
npm run dev
```

## Quality commands

```bash
npm run typecheck
npm run build
npm run preview
```

## Current scope

The current update focuses on the shared application shell, navigation, header interactions, Theme Customizer, Settings page, and Sales Dashboard. The Theme Customizer includes preset and custom colors, light/dark/system mode, font, radius, scale, seven one-click dashboard layouts (Default, Full Navbar, Horizontal, Split, Icon Menu, Paper, and the additional Adaptive layout), relevant sidebar controls, content width, import/export, and reset controls. Layout selection applies immediately and persists in browser storage. Analytics, Orders, Products, Customers, and Finance are intentionally retained unchanged and excluded from this update.

## Demo-data and integration boundaries

The application uses sample data. Theme, profile settings, and locally created demo invoices are stored in the current browser only. Payment methods, payment management, subscription management, and notifications are illustrative; no real payment is processed and no card/CVC data is collected. Local demo invoices are not legally valid tax invoices and are not synchronized to a backend.

See [CODE_QUALITY_REPORT.md](./CODE_QUALITY_REPORT.md), [SECOND_REVIEW_REPORT.md](./SECOND_REVIEW_REPORT.md), and [LAYOUT_SYSTEM_REPORT.md](./LAYOUT_SYSTEM_REPORT.md) for review details, layout behaviour, and verification limitations.
